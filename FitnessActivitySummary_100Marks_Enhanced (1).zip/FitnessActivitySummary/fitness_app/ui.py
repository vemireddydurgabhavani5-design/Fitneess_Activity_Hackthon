import os
from datetime import datetime
from .models import Activity, VALID_CATEGORIES
from .validation import validate_date, validate_choice, validate_positive_float, validate_nonnegative_int, validate_notes
from .storage import load_json, save_all, load_csv
from .analytics import totals, averages, status, streak, search, category_counts, intensity_counts, best_activity
from .plots import create_weekly_chart, create_category_chart
from .reports import generate_markdown, generate_audit_log
from .goals import load_goals, save_goals, progress

RESET='\033[0m'; BOLD='\033[1m'; CYAN='\033[96m'; GREEN='\033[92m'; YELLOW='\033[93m'; RED='\033[91m'
def clear(): os.system('cls' if os.name == 'nt' else 'clear')
def banner():
    print(f'{CYAN}{BOLD}\n╔══════════════════════════════════════════════════════════════╗\n║              FITNESS ACTIVITY SUMMARY 2.0                   ║\n║          DataSpark Challenge • Project #34                  ║\n╚══════════════════════════════════════════════════════════════╝{RESET}')
def ask(prompt, validator):
    while True:
        try: return validator(input(prompt))
        except ValueError as e: print(f'{RED}✗ {e} Try again.{RESET}')
def next_id(records): return max((r.id for r in records), default=0)+1

def activity_form(records, existing=None):
    r = existing
    date = ask(f"Date [{r.date if r else 'YYYY-MM-DD'}]: ", validate_date) if not r else ask(f"Date [{r.date}]: ", lambda x: validate_date(x or r.date))
    category = ask(f"Category [{r.category if r else ''}] ({', '.join(VALID_CATEGORIES)}): ", lambda x: validate_choice(x or (r.category if r else ''), VALID_CATEGORIES))
    duration = ask(f"Duration minutes [{r.duration_minutes if r else ''}]: ", lambda x: validate_positive_float(x or str(r.duration_minutes if r else ''), 'Duration', 1440))
    distance = ask(f"Distance km [{r.distance_km if r else ''}]: ", lambda x: validate_positive_float(x or str(r.distance_km if r else ''), 'Distance', 1000))
    calories = ask(f"Calories [{r.calories if r else ''}]: ", lambda x: validate_positive_float(x or str(r.calories if r else ''), 'Calories', 10000))
    steps = ask(f"Steps [{r.steps if r else ''}]: ", lambda x: validate_nonnegative_int(x or str(r.steps if r else ''), 'Steps', 100000))
    intensity = ask(f"Intensity [{r.intensity if r else ''}] (Low/Moderate/High): ", lambda x: validate_choice(x or (r.intensity if r else ''), ['Low','Moderate','High']))
    notes = validate_notes(input(f"Notes [{r.notes if r else ''}]: ") or (r.notes if r else ''))
    return Activity(r.id if r else next_id(records), date, category, duration, distance, calories, steps, intensity, notes)

def add_activity(records):
    print(f'\n{BOLD}➜ Record New Activity{RESET}'); records.append(activity_form(records)); save_all(records); print(f'{GREEN}✓ Activity saved.{RESET}')
def edit_activity(records):
    show_records(records); rid=input('Enter ID to edit: ').strip()
    try: r=next(x for x in records if x.id==int(rid))
    except (ValueError, StopIteration): print(f'{RED}Record not found.{RESET}'); return
    updated=activity_form(records,r); records[records.index(r)]=updated; save_all(records); print(f'{GREEN}✓ Updated.{RESET}')
def delete_activity(records):
    show_records(records); rid=input('Enter ID to delete: ').strip()
    try: r=next(x for x in records if x.id==int(rid))
    except (ValueError, StopIteration): print(f'{RED}Record not found.{RESET}'); return
    if input(f'Delete {r.category} on {r.date}? (yes/no): ').strip().lower()=='yes': records.remove(r); save_all(records); print(f'{GREEN}✓ Deleted.{RESET}')

def show_records(records, rows=None):
    rows=records if rows is None else rows
    if not rows: print(f'{YELLOW}No matching records found.{RESET}'); return
    print('\n'+'-'*122); print(f"{'ID':<4}{'Date':<12}{'Category':<12}{'Min':>8}{'Km':>9}{'Cal':>9}{'Steps':>10}{'Intensity':<11} Notes"); print('-'*122)
    for r in rows: print(f'{r.id:<4}{r.date:<12}{r.category:<12}{r.duration_minutes:>8.1f}{r.distance_km:>9.2f}{r.calories:>9.0f}{r.steps:>10}{r.intensity:<11} {r.notes[:30]}')
    print('-'*122)

def dashboard(records):
    t,a=totals(records),averages(records); print(f'\n{BOLD}EXECUTIVE DASHBOARD{RESET}')
    print(f'Status: {GREEN}{status(records)}{RESET}   Best streak: {streak(records)} day(s)')
    print(f"Sessions: {t['sessions']} | Duration: {t['duration']:.1f} min | Distance: {t['distance']:.2f} km | Calories: {t['calories']:.0f} | Steps: {t['steps']}")
    if records: print(f"Average/session: {a['duration']:.1f} min | {a['distance']:.2f} km | {a['calories']:.1f} kcal | {a['steps']:.0f} steps")
    b=best_activity(records)
    if b: print(f'Best calorie session: #{b.id} {b.category} — {b.calories:.0f} kcal ({b.date})')
    print('Categories:', ', '.join(f'{k} ({v})' for k,v in category_counts(records).most_common()) or 'None')
    print('Intensity:', ', '.join(f'{k} ({v})' for k,v in intensity_counts(records).most_common()) or 'None')

def goals_menu(records):
    goals=load_goals(); p=progress(records,goals)
    print(f"\n{BOLD}WEEKLY GOALS{RESET}\nMinutes: {p['minutes']:.0f}/{goals['weekly_minutes']:.0f} ({p['minutes_pct']:.0f}%)\nSessions: {p['sessions']}/{goals['weekly_sessions']:.0f} ({p['sessions_pct']:.0f}%)\nSteps: {p['steps']}/{goals['daily_steps']:.0f} daily target reference ({p['steps_pct']:.0f}%)")
    if input('Edit goals? (y/n): ').lower()=='y':
        for key,label in [('weekly_minutes','Weekly minutes'),('weekly_sessions','Weekly sessions'),('daily_steps','Daily steps')]:
            goals[key]=float(ask(f'{label}: ', lambda x: validate_positive_float(x,label,1000000)))
        save_goals(goals); print(f'{GREEN}✓ Goals saved.{RESET}')

def search_menu(records):
    keyword=input('Keyword/date/note (blank=all): '); category=input('Category (All or specific): ') or 'All'
    try: category=validate_choice(category,('All',)+VALID_CATEGORIES)
    except ValueError as e: print(e); return
    show_records(records,search(records,keyword,category))
def import_csv(records):
    try:
        imported=load_csv(input('CSV path: ').strip()); start=max((r.id for r in records),default=0)+1
        for r in imported: r.id=start; start+=1; records.append(r)
        save_all(records); print(f'{GREEN}✓ Imported {len(imported)} row(s).{RESET}')
    except (OSError,ValueError) as e: print(f'{RED}Import failed: {e}{RESET}')

def run_app():
    records=load_json()
    while True:
        clear(); banner(); print(f'Stored records: {len(records)} | Last loaded: {datetime.now().strftime("%Y-%m-%d %H:%M")}')
        print('''\n1. Record new activity\n2. View all activities\n3. Edit activity\n4. Delete activity\n5. Search / filter records\n6. Executive dashboard\n7. Weekly goals & progress\n8. Generate charts\n9. Export reports\n10. Import validated CSV\n11. Save & exit''')
        c=input('\nSelect an option: ').strip()
        if c=='1': add_activity(records)
        elif c=='2': show_records(records)
        elif c=='3': edit_activity(records)
        elif c=='4': delete_activity(records)
        elif c=='5': search_menu(records)
        elif c=='6': dashboard(records)
        elif c=='7': goals_menu(records)
        elif c=='8':
            print(f'Weekly chart: {create_weekly_chart(records)}'); print(f'Category chart: {create_category_chart(records)}')
        elif c=='9': print(f'Summary: {generate_markdown(records)}\nAudit log: {generate_audit_log(records)}')
        elif c=='10': import_csv(records)
        elif c=='11': save_all(records); print(f'{GREEN}✓ Data saved. Goodbye!{RESET}'); break
        else: print(f'{RED}Invalid option.{RESET}')
        input('\nPress Enter to continue...')
