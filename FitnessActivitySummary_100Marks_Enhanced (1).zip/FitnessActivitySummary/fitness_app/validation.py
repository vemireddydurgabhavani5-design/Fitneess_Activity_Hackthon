import re
from datetime import datetime
from .models import VALID_CATEGORIES

def validate_date(value: str) -> str:
    value = value.strip()
    try:
        d = datetime.strptime(value, "%Y-%m-%d")
        if d.year < 2000 or d > datetime.now():
            raise ValueError
        return d.strftime("%Y-%m-%d")
    except ValueError:
        raise ValueError("Enter a valid date (YYYY-MM-DD), not in the future.")

def validate_choice(value: str, choices) -> str:
    value = value.strip()
    for choice in choices:
        if value.lower() == choice.lower():
            return choice
    raise ValueError("Invalid choice. Select one of the listed options.")

def validate_positive_float(value: str, name: str, maximum: float) -> float:
    try:
        x = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be numeric.")
    if x <= 0 or x > maximum:
        raise ValueError(f"{name} must be > 0 and <= {maximum:g}.")
    return round(x, 2)

def validate_nonnegative_int(value: str, name: str, maximum: int) -> int:
    if not re.fullmatch(r"\d+", value.strip()):
        raise ValueError(f"{name} must be a whole number.")
    x = int(value)
    if x < 0 or x > maximum:
        raise ValueError(f"{name} must be between 0 and {maximum}.")
    return x

def validate_notes(value: str) -> str:
    return value.strip()[:200]
