from pathlib import Path
import matplotlib.pyplot as plt
from .analytics import weekly_trend, category_counts

BASE_DIR = Path(__file__).resolve().parent.parent
REPORT_DIR = BASE_DIR / "reports"

def _setup():
    REPORT_DIR.mkdir(parents=True, exist_ok=True)

def create_weekly_chart(records):
    _setup()
    data = weekly_trend(records)
    labels = list(data.keys())
    minutes = [data[k]["minutes"] for k in labels]
    plt.figure(figsize=(10, 5))
    plt.plot(labels, minutes, marker="o")
    plt.title("Weekly Activity Duration")
    plt.xlabel("Week starting")
    plt.ylabel("Minutes")
    plt.xticks(rotation=35, ha="right")
    plt.grid(True, alpha=.25)
    plt.tight_layout()
    path = REPORT_DIR / "weekly_activity_trend.png"
    plt.savefig(path, dpi=160)
    plt.close()
    return path

def create_category_chart(records):
    _setup()
    counts = category_counts(records)
    labels, values = list(counts.keys()), list(counts.values())
    plt.figure(figsize=(8, 5))
    plt.bar(labels, values)
    plt.title("Sessions by Activity Category")
    plt.xlabel("Category")
    plt.ylabel("Sessions")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    path = REPORT_DIR / "activity_categories.png"
    plt.savefig(path, dpi=160)
    plt.close()
    return path
