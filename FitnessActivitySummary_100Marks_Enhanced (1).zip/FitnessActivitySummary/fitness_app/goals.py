from pathlib import Path
import json

BASE_DIR = Path(__file__).resolve().parent.parent
GOALS_FILE = BASE_DIR / 'data' / 'goals.json'
DEFAULT_GOALS = {'weekly_minutes': 150, 'weekly_sessions': 5, 'daily_steps': 8000}

def load_goals():
    GOALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not GOALS_FILE.exists():
        save_goals(DEFAULT_GOALS)
        return DEFAULT_GOALS.copy()
    try:
        data = json.loads(GOALS_FILE.read_text(encoding='utf-8'))
        return {**DEFAULT_GOALS, **{k: float(v) for k, v in data.items()}}
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return DEFAULT_GOALS.copy()

def save_goals(goals):
    GOALS_FILE.parent.mkdir(parents=True, exist_ok=True)
    GOALS_FILE.write_text(json.dumps(goals, indent=2), encoding='utf-8')

def progress(records, goals=None):
    goals = goals or load_goals()
    from datetime import datetime, timedelta
    today = datetime.now().date()
    start = today - timedelta(days=today.weekday())
    current = [r for r in records if start <= datetime.strptime(r.date, '%Y-%m-%d').date() <= today]
    minutes = sum(r.duration_minutes for r in current)
    sessions = len(current)
    steps = sum(r.steps for r in current)
    return {
        'minutes': minutes, 'sessions': sessions, 'steps': steps,
        'minutes_pct': min(100, minutes / goals['weekly_minutes'] * 100) if goals['weekly_minutes'] else 0,
        'sessions_pct': min(100, sessions / goals['weekly_sessions'] * 100) if goals['weekly_sessions'] else 0,
        'steps_pct': min(100, steps / goals['daily_steps'] * 100) if goals['daily_steps'] else 0,
    }
