from dataclasses import dataclass, asdict
from datetime import datetime
from typing import Any

VALID_CATEGORIES = ("Walking", "Running", "Cycling", "Workout", "Yoga", "Swimming", "Other")

@dataclass
class Activity:
    id: int
    date: str
    category: str
    duration_minutes: float
    distance_km: float
    calories: float
    steps: int
    intensity: str
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @staticmethod
    def from_dict(data: dict[str, Any]) -> "Activity":
        return Activity(
            id=int(data["id"]),
            date=str(data["date"]),
            category=str(data["category"]),
            duration_minutes=float(data["duration_minutes"]),
            distance_km=float(data["distance_km"]),
            calories=float(data["calories"]),
            steps=int(data["steps"]),
            intensity=str(data["intensity"]),
            notes=str(data.get("notes", "")),
        )
