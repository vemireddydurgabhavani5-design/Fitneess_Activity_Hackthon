from pathlib import Path
from datetime import datetime
from .analytics import totals, averages, category_counts, intensity_counts, status, streak

BASE_DIR = Path(__file__).resolve().parent.parent
REPORT_DIR = BASE_DIR / "reports"

def generate_markdown(records):
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    t, a = totals(records), averages(records)
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    lines = [
        "# Fitness Activity Summary",
        f"Generated: {now}",
        "",
        f"**Status:** {status(records)}",
        f"**Best active-day streak:** {streak(records)} day(s)",
        "",
        "## Executive Metrics",
        "| Metric | Total | Average/session |",
        "|---|---:|---:|",
        f"| Sessions | {t['sessions']} | - |",
        f"| Duration (min) | {t['duration']:.1f} | {a['duration']:.1f} |",
        f"| Distance (km) | {t['distance']:.2f} | {a['distance']:.2f} |",
        f"| Calories | {t['calories']:.0f} | {a['calories']:.1f} |",
        f"| Steps | {t['steps']} | {a['steps']:.0f} |",
        "",
        "## Category Breakdown",
    ]
    for k, v in category_counts(records).most_common():
        lines.append(f"- **{k}:** {v} session(s)")
    lines += ["", "## Intensity Breakdown"]
    for k, v in intensity_counts(records).most_common():
        lines.append(f"- **{k}:** {v} session(s)")
    path = REPORT_DIR / "fitness_summary.md"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path

def generate_audit_log(records):
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    path = REPORT_DIR / "audit_log.txt"
    with path.open("w", encoding="utf-8") as f:
        f.write("FITNESS ACTIVITY AUDIT LOG\n")
        f.write("=" * 55 + "\n")
        for r in records:
            f.write(f"[{r.date}] #{r.id} {r.category} | {r.duration_minutes:.1f} min | "
                    f"{r.distance_km:.2f} km | {r.calories:.0f} kcal | "
                    f"{r.steps} steps | {r.intensity} | {r.notes}\n")
    return path
