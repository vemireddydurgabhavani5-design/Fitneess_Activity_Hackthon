from collections import Counter
from datetime import datetime, timedelta
from statistics import mean
from .models import Activity

def totals(records):
    return {'sessions': len(records), 'duration': sum(r.duration_minutes for r in records),
            'distance': sum(r.distance_km for r in records), 'calories': sum(r.calories for r in records),
            'steps': sum(r.steps for r in records)}

def averages(records):
    if not records:
        return {'duration': 0, 'distance': 0, 'calories': 0, 'steps': 0}
    return {'duration': mean(r.duration_minutes for r in records), 'distance': mean(r.distance_km for r in records),
            'calories': mean(r.calories for r in records), 'steps': mean(r.steps for r in records)}

def category_counts(records): return Counter(r.category for r in records)
def intensity_counts(records): return Counter(r.intensity for r in records)

def weekly_trend(records, weeks=8):
    today = datetime.now().date(); start = today - timedelta(days=weeks * 7 - 1)
    buckets = {}
    for i in range(weeks):
        d = start + timedelta(days=i * 7); buckets[d.strftime('%Y-%m-%d')] = {'sessions': 0, 'minutes': 0}
    for r in records:
        try: d = datetime.strptime(r.date, '%Y-%m-%d').date()
        except ValueError: continue
        idx = (d - start).days // 7
        if 0 <= idx < weeks:
            key = (start + timedelta(days=idx * 7)).strftime('%Y-%m-%d')
            buckets[key]['sessions'] += 1; buckets[key]['minutes'] += r.duration_minutes
    return buckets

def monthly_totals(records):
    result = Counter()
    for r in records:
        try: result[r.date[:7]] += r.duration_minutes
        except Exception: pass
    return dict(sorted(result.items()))

def status(records):
    t = totals(records)
    if not t['sessions']: return 'NO DATA'
    if t['duration'] >= 150 and t['sessions'] >= 5: return 'EXCELLENT'
    if t['duration'] >= 90: return 'GOOD'
    return 'BUILDING'

def streak(records):
    dates = sorted({datetime.strptime(r.date, '%Y-%m-%d').date() for r in records}, reverse=True)
    if not dates: return 0
    best = current = 1
    for a, b in zip(dates, dates[1:]):
        if (a-b).days == 1: current += 1; best = max(best, current)
        else: current = 1
    return best

def best_activity(records):
    return max(records, key=lambda r: r.calories, default=None)

def search(records, keyword='', category='All'):
    keyword = keyword.strip().lower()
    return [r for r in records if (category == 'All' or r.category.lower() == category.lower()) and
            (not keyword or keyword in r.date.lower() or keyword in r.category.lower() or
             keyword in r.intensity.lower() or keyword in r.notes.lower())]
