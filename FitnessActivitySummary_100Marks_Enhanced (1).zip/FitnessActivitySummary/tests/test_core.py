import unittest
from fitness_app.models import Activity
from fitness_app.analytics import totals, status, streak, search, best_activity
from fitness_app.validation import validate_date, validate_positive_float

class TestFitnessCore(unittest.TestCase):
    def setUp(self):
        self.records = [
            Activity(1, '2026-11-10', 'Walking', 30, 2.5, 140, 4000, 'Moderate', 'campus'),
            Activity(2, '2026-11-11', 'Running', 45, 5.0, 380, 6000, 'High', 'evening'),
            Activity(3, '2026-11-12', 'Walking', 35, 3.0, 160, 4500, 'Moderate', 'campus'),
        ]
    def test_totals(self):
        t=totals(self.records); self.assertEqual(t['sessions'],3); self.assertEqual(t['steps'],14500)
    def test_search(self):
        self.assertEqual(len(search(self.records,'campus')),2); self.assertEqual(len(search(self.records,category='Running')),1)
    def test_streak(self): self.assertEqual(streak(self.records),3)
    def test_best_activity(self): self.assertEqual(best_activity(self.records).id,2)
    def test_validation(self):
        self.assertEqual(validate_date('2026-11-18'),'2026-11-18'); self.assertEqual(validate_positive_float('25','Duration',100),25.0)
        with self.assertRaises(ValueError): validate_positive_float('abc','Duration',100)

if __name__=='__main__': unittest.main()
